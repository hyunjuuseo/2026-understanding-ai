@echo off
setlocal
echo Loading Poker. Wait for the game window to open.
set "PYGAME_HIDE_SUPPORT_PROMPT=1"
set "PYTHONPATH=%~dp0..\..\work\deps"
cd /d "%~dp0" || exit /b 1
"C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1110-973-0_26.1110.973.0_x64__3k8sg7r9htsxt\dependencies\python\python.exe" -u "%~dp0poker.py"
if errorlevel 1 pause


