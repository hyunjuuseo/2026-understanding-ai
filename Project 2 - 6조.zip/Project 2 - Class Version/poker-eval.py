import pickle
from pathlib import Path

import pandas as pd

_model_dir = Path(__file__).resolve().parent
with (_model_dir / "poker-model3.sav").open("rb") as file:
    model3 = pickle.load(file)
with (_model_dir / "poker-model4.sav").open("rb") as file:
    model4 = pickle.load(file)


def card_features(cards):
    card_count = cards.shape[1] // 2
    suits = cards.iloc[:, ::2]
    ranks = cards.iloc[:, 1::2]

    same_suit = 0
    same_rank = 0
    for first in range(card_count):
        for second in range(first + 1, card_count):
            same_suit = same_suit + (suits.iloc[:, first] == suits.iloc[:, second]).astype(int)
            same_rank = same_rank + (ranks.iloc[:, first] == ranks.iloc[:, second]).astype(int)

    return pd.DataFrame({"same_rank": same_rank, "same_suit": same_suit})



def predict_call(hand, opposite_score):
    model = model3 if len(hand) == 3 else model4

    card_values = []
    for suit, rank in hand:
        card_values.extend([suit, rank])
    cards = pd.DataFrame([card_values])
    probabilities = model.predict_proba(card_features(cards))[0]

    expected_money = 0
    for score, probability in zip(model.classes_, probabilities):
        if score > opposite_score:
            expected_money += 3 * probability
        elif score < opposite_score:
            expected_money -= 3 * probability

    fold_money = -1 if len(hand) == 3 else -2
    return bool(expected_money >= fold_money)


import numpy as np
import random

test = pd.read_csv('poker-hand-testing.csv')

money = [1000] * 10
for i in range(10):
    samp = np.random.randint(0, len(test), size=1000)
    X_test = test.iloc[samp, :-1].to_numpy()
    y_test = test.iloc[samp, -1].to_numpy()

    for test_hand, test_score in zip(X_test, y_test):
        test_input = [ (suit, rank) for suit, rank in zip(test_hand[::2], test_hand[1::2]) ]
        oppo_score = y_test[random.randrange(len(y_test))]

        if not predict_call(test_input[:3], oppo_score):
            money[i] -= 1
            continue

        if not predict_call(test_input[:4], oppo_score):
            money[i] -= 2
            continue

        if test_score > oppo_score:
            money[i] += 3

        elif test_score < oppo_score:
            money[i] -= 3
        # if tie, your money stays the same

print('average of money= {}'.format(round(np.mean(money), 3)))